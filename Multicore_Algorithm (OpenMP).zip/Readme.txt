This is an OpenMP-based CPU multicore implementation of test case of the flow of ocular aqueous humor from the paper “An efficient GPU algorithm for lattice Boltzmann method on sparse complex geometries”. You can:
1. Generate the executable program using the command "g++ -fopenmp multicore_algorithm.c -o multicore_algorithm";
2. Run the supplied executable program ”multicore_algorithm”directly. 