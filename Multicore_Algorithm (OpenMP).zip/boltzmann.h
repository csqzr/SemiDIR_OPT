#pragma once
#include "eye.h"


//-----------------------------------------------------------------------------
#define RE_TAU_F   1.0                                 
#define RE_TAU_T   1.765945			                   
#define RE_TAU_T_C   1.776217			              
double  IOP_QUANTI_COF;                              
double dx, dt;										
double avg_p0,avg_p1;								
double total_Den, total_Tem;						
double DetaL, DimLen, DimTime;
double G;                                         

int NX;								           
int NFluid;
int NInlet;
int NOutlet;
int NBoundary;
int NCornea_Solid;
int NIris_Solid;
int NOuter_cornea_boundary;

unsigned int *FIndex;
int *NIndex;
 double *Ux;                        
 double *Uy;                        
 double *Uz;                        
 double *Den;                       
 double *Tem;                       
 double *F;                           //Velocity distribution function
 double  *T;                          //Temperature distribution function

int N_Evolution;									

int fileSaveCount;									
int startTime, endTime;
int just_nos = 0;                                  

void Initialize();											
void MallocMemory();										
void SetType();
void SetGeometryFeild();

double SetU(double U, int x, int y, int z, int r);	
double Feq(int f, double pressure, double ux, double uy, double uz);
double Teq(int f, double temperature, double ux, double uy, double uz);

double ComputeMLUPS(int N_Lattice, int t);		
void   ShowTime(int time);

void FileSaveCount();
void SaveType();


void Initialize()
{
	
	dx = 1.0, dt = 1.0;
	Bta = 0.00032;
	Pr = 5.03;
	Gravity = -9.81;
	C_AH = 4.178E3;
	PHY_ROU = 9.93E2;
	PHY_MU = 6.947E-4;
	NIU = PHY_MU / PHY_ROU;

	Q_In = 2.5;
	Q_Out = 2.5;

	tau_f = 1.0;
	Re_tau_f = 1.0 / tau_f;
	niu = ((2 * tau_f - 1) / 6) * (dx*dx / dt);
	chi = niu / Pr;

	//tau_t = 3 * chi*dt / (dx*dx) + 0.5;

	tau_t = 2 * chi*dt / (dx*dx) + 0.5;

	Re_tau_t = 1.0 / tau_t;

	DetaL = 1E-3;
	DimLen = 1E-3 / DetaX;
	DimTime = (niu / NIU)*DimLen*DimLen;

	double Re_tau_t_c = 1.0 / (2.0*CORNEA_D*DimTime / (DimLen*DimLen) + 0.5);

	gravity = Gravity * Sq(DimTime) / DimLen;

	K_Permeability = 7.0E-15;
	

	G = PHY_ROU*DimLen*DimLen*DimLen;
	IOP_QUANTI_COF = G / (DimLen*DimTime*DimTime);
	IOP= PRESSURE*DimLen*DimTime*DimTime /G;

#ifdef FORCE_STAND
	cout << " FORCE_STAND " << endl;
	TM_Thickness = 0.0032294811111;
#endif // FORCE_STAND
#ifdef FORCE_SUPINE
	cout << " FORCE_SUPINE " << endl;
	TM_Thickness = 0.0032822320000;
#endif // FORCE_SUPINE
#
	U_Out_Coefficient = K_Permeability / (PHY_MU * TM_Thickness) * DimTime / DimLen;

	V_In = 2 * Pi*(PC_width * DetaL / 2.0) * PC_height * DetaL;
	V_Out = 2 * Pi * R_CORNEA * DetaL * TM_HEIGHT * DetaL;

	U_In = (Q_In / 60.0 * DetaL*DetaL*DetaL) / V_In;
	U_Out = (Q_Out / 60.0 * DetaL*DetaL*DetaL) / V_Out;

	U_In = U_In * (DimTime / DimLen);
	U_Out = U_Out * (DimTime / DimLen);

	printf("PC_width       = "); cout << PC_width << endl;
	printf("PC_height      = "); cout << PC_height << endl;

	printf("R_CORNEA       = "); cout << R_CORNEA << endl;
	printf("TM_HEIGHT      = "); cout << TM_HEIGHT << endl;
	printf(" hot tempreture T_H : ");	cout << T_H << endl;
	printf(" cold tempreture T_L : ");	cout << T_L << endl;

	printf("   tau_f : ");	cout << tau_f << endl;
	printf("   niu     : ");	cout << niu << endl;
	printf("   chi   : ");	cout << chi << endl;
	printf("   tau_t : ");	cout << tau_t << endl;
	printf("   gravity         : ");	cout << gravity << endl;
	printf("lattice DimLen       = ");		cout << DimLen << endl;
	printf("lattice DimTime      = ");		cout << DimTime << endl;

	cout << "  TM_Thickness = " << setprecision(13) << TM_Thickness << endl;
	cout << "  U_Out_Coefficient = " << setprecision(13) << U_Out_Coefficient << endl;
	printf("lattice U_In       = "); cout << U_In << endl;
	printf("lattice U_Out      = "); cout << U_Out << endl;

}

void MallocMemory()
{
	Type = new int[DX*DY*DZ];
	

	if (Type == 0 )
	{
		cout << "Memory allocation is error ..." << endl << flush;
		cin.get();
		exit(1);
	}

}

void SetType()
{
	SetGeometry();                   
}

void SetGeometryFeild()
{
	cout << "			   DetaX = " << DetaX << endl;
	cout << "   feild      DX = " << DX << endl;
	cout << "              DY = " << DY << endl;
	cout << "              DZ = " << DZ << endl;

	MallocMemory();
	SetType();
	Initialize();
}

double SetU(double U, int x, int y, int z, int r)
{
	double d = sqrt(double(x*x + y*y + z*z));

	return r / d * U;
}

double Feq(int f, double pressure, double ux, double uy, double uz)
{
	if (f == 0)
		return -2.0*pressure + h_W[f] * (3.0 * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz)
			+ 4.5 * ((h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz) * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz))
			- 1.5 * (ux * ux + uy * uy + uz * uz));
	if (f >= 1 && f <= 6)
		return pressure / 6.0 + h_W[f] * (3.0 * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz)
			+ 4.5 * ((h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz) * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz))
			- 1.5 * (ux * ux + uy * uy + uz * uz));

	if (f >= 7)
		return pressure / 12.0 + h_W[f] * (3.0 * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz)
			+ 4.5 * ((h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz) * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz))
			- 1.5 * (ux * ux + uy * uy + uz * uz));
}

double Teq(int f, double temperature, double ux, double uy, double uz)
{

	return temperature / 6.0*(1 + 3.0 * (h_Ex[f] * ux + h_Ey[f] * uy + h_Ez[f] * uz));
}

double ComputeMLUPS(int N_Lattice, int t)
{
	double MLUPS = (double(ALLSTEP) / 1e6) * (N_Lattice / ((double)t / 1000 /*CLOCKS_PER_SEC*/));
	cout << " MLUPS = " << MLUPS << endl;
	return MLUPS;
}

void ShowTime(int time)
{
	int mSecond;
	int second;
	int minute;
	int hour;
	int day;

	cout << "   total time : " << (double)time / 1000 /*CLOCKS_PER_SEC*/ << " s " << endl;

	mSecond = time % 1000;
	time /= 1000;

	second = time % 60;
	time /= 60;

	minute = time % 60;
	time /= 60;

	hour = time % 24;
	time /= 24;

	day = time;

	cout << "   " << "the total running time of the program is : ";
	if (day > 0)
		cout << day << " day ";
	if (hour > 0)
		cout << hour << " hour ";
	if (minute > 0)
		cout << minute << " minute ";
	if (second > 0)
		cout << second << " s ";
	cout << mSecond << " mSec " << endl;

}




