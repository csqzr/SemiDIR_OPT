
#pragma once

#include <math.h>
#include <stdio.h>
#include <iomanip>
#include <iostream>

using namespace std;

#pragma warning (disable : 4996) 
#pragma warning (disable : 4244) 
#pragma warning (disable : 4819) 


#define D3Q19T7

#define ALLSTEP 10000/*6000000*/ /*12000000*/                             
#define SHOWSTEP 200                      

#define FORCE_STAND										// External force term in the standing position
//#define FORCE_SUPINE									// External force term in the spine position

#define DetaX 30                                        //Scale: number of nodes represented by 1 mm

//flow field
const int DX = int(13.9 * DetaX)+6;                        
const int DY = int(13.9 * DetaX)+6;
const int DZ = int(4.5 * DetaX);                          

														
#define  UNKNOWED -1                                 //Unknowed type
#define  FLUID 1		                             //Type of aqueous humor 
#define  BOUNDARY 4	
#define TM_OUTLET  6                                 //Outlet type
#define PC_INLET   8                                 //Inlet type
#define CORNEA_SOLID 0                               //Corneal solid type
#define IRIS_SOLID 11                                //Iris solid type
#define LENS_SOLID 12                                //Lens solid type
#define CORNEA_BOUNDARY 13                           //Corneal boundary Type
#define IRIS_BOUNDARY 14                             //Iris boundary Type
#define LENS_BOUNDARY 15                             //Lens boundary Type
#define LIGAMENT_BOUNDARY 16                         //Types of suspensory ligaments between the lens and sclera
#define OUTER_CORNEA_BOUNDARY 17                     //Type of outer corneal boundary
#define INNER_CORNEA_BOUNDARY 18                     //Type of inner corneal boundary
#define OUTER_SCLERA_BOUNDARY 19                     //Type of inner sclera boundary
#define SCLERA_SOLID 20                              //Scleral solid type


#define Pi 3.1415926535897932384626433832795


#ifdef D3Q19T7
#define DF  19                                 
#define DT  7                                   
const int DN = 6;									

const int Ex[DF] = { 0, 1, -1, 0,  0, 0,  0, 1, -1,  1, -1,  1,  -1, -1,   1,  0,  0,  0,  0 };
const int Ey[DF] = { 0, 0,  0, 1, -1, 0,  0, 1, -1, -1,  1,  0,   0,  0,   0,  1, -1,  1, -1 };
const int Ez[DF] = { 0, 0,  0, 0,  0, 1, -1, 0,  0,  0,  0,  1,  -1,  1,  -1,  1, -1, -1,  1 };

//----CPU----------------------------
const int   h_Ex[DF] = { 0, 1,-1, 0, 0, 0, 0, 1, -1, 1,-1, 1, -1, -1, 1, 0, 0, 0, 0 };
const int   h_Ey[DF] = { 0, 0, 0, 1,-1, 0, 0, 1, -1, -1, 1, 0, 0, 0, 0, 1, -1, 1, -1 };
const int   h_Ez[DF] = { 0, 0, 0, 0, 0, 1, -1, 0, 0, 0, 0, 1, -1, 1, -1, 1, -1, -1, 1 };
const int   h_Re[DF] = { 0, 2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15, 18, 17 };
const double h_W[DF] = { 1.0 / 3, 1.0 / 18 ,1.0 / 18, 1.0 / 18, 1.0 / 18, 1.0 / 18, 1.0 / 18, 1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36,1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36,1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36 };   
const double h_N[DT] = { 1.0 / 4, 1.0 / 8, 1.0 / 8, 1.0 / 8, 1.0 / 8, 1.0 / 8, 1.0 / 8 };

//----GPU----------------------------
const int   d_Ex[DF] = { 0, 1, -1, 0,  0, 0,  0, 1, -1,  1, -1,  1,  -1, -1,   1,  0,  0,  0,  0 };
const int   d_Ey[DF] = { 0, 0,  0, 1, -1, 0,  0, 1, -1, -1,  1,  0,   0,  0,   0,  1, -1,  1, -1 };
const int   d_Ez[DF] = { 0, 0,  0, 0,  0, 1, -1, 0,  0,  0,  0,  1,  -1,  1,  -1,  1, -1, -1,  1 };
const int   d_Re[DF] = { 0, 2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15, 18, 17 };
const double d_W[DF] = { 1.0 / 3, 1.0 / 18 ,1.0 / 18, 1.0 / 18, 1.0 / 18, 1.0 / 18, 1.0 / 18, 1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36,1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36,1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36 };
const double d_N[DT] = { 1.0 / 4, 1.0 / 8, 1.0 / 8, 1.0 / 8, 1.0 / 8, 1.0 / 8, 1.0 / 8 };

#define _R d_Re[f]

inline double d_Feq(int f, double pressure, double ux, double uy, double uz)
{
	if (f == 0)
		return -2.0*pressure + d_W[f] * (3.0 * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz)
			+ 4.5 * ((d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz) * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz))
			- 1.5 * (ux * ux + uy * uy + uz * uz));
	if (f >= 1 && f <= 6)
		return pressure / 6.0 + d_W[f] * (3.0 * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz)
			+ 4.5 * ((d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz) * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz))
			- 1.5 * (ux * ux + uy * uy + uz * uz));

	if (f >= 7)
		return pressure / 12.0 + d_W[f] * (3.0 * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz)
			+ 4.5 * ((d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz) * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz))
			- 1.5 * (ux * ux + uy * uy + uz * uz));

}

inline double d_Teq(int f, double temperature, double ux, double uy, double uz)
{
	return  temperature / 6.0*(1 + 3.0 * (d_Ex[f] * ux + d_Ey[f] * uy + d_Ez[f] * uz));
}

inline double d_SetU(double U, int x, int y, int z, int r)
{
	double d = sqrt(double(x*x + y*y + z*z));

	return r / d * U;
}

#endif


#define FOR_iDX_jDY      for(int i=0; i<DX; i++) for(int j=0; j<DY; j++) 
#define FOR_jDY_iDX      for(int j=0; j<DY; j++) for(int i=0; i<DX; i++) 
#define FOR_iDX_jDY_kDZ  for(int i=0; i<DX; i++) for(int j=0; j<DY; j++) for(int k=0; k<DZ; k++) 
#define FOR_kDZ_iDX_jDY  for(int k=0; k<DZ; k++) for(int i=0; i<DX; i++) for(int j=0; j<DY; j++)  
#define FOR_kDZ_jDY_iDX  for(int k=0; k<DZ; k++) for(int j=0; j<DY; j++) for(int i=0; i<DX; i++)

#define FOR_fDF          for(int f=0; f<DF; f++)
#define INT_ii_jj_kk_IF  int ii = i + Ex[f], jj = j + Ey[f], kk = k + Ez[f]; if (ii >= 0 && ii <= DX - 1 && jj >= 0 && jj <= DY - 1 && kk >= 0 && kk <= DZ - 1)

#define FOR_iDX_jDY_kDZ_Fluid for(int i=0; i<DX; i++) for(int j=0; j<DY; j++) for(int k=0; k<DZ; k++) if(Type[i*DY*DZ + j*DZ + k] == FLUID)
#define FOR_nALLSTEP          for(int n=1; n<=ALLSTEP; n++)


#define Sq(x) ((x) * (x))


