

//---------------------------------------------------------------------
// 
//************Geometric modeling of the anterior segment***************
// 
//---------------------------------------------------------------------

#pragma once
#include "common.h"

double AC_depth;								//mm  Anterior chamber depth
double IRIS_thickness;                          //mm  Iris thickness

double PUPIL_size;								//mm  Pupil size
double D_IRIS_LENS;								//mm  Minimum distance between iris and lens
double R_LENS;                                  //mm  Radius of  lens

double IRIS_ANGLE;								//  Anterior chamber angle size
double Tan_IRIS_ANGLE;							//  Tangent value of iris angle in the Z direction

												
double TM_ANGLE;                                 // Angle between trabecular mesh and horizontal plane (YOZ plane)
double Sin_TM_ANGLE;							 // Sine of the angle between the trabecular mesh and the horizontal plane (YOZ plane)
double TM_LENGTH;                                //mm  Arc length of trabecular mesh

int d_TM;										 // Node number of height of trabecular mesh

int d_PC_height;								// Node number in the x-direction of the height in posterior room
int d_IRIS_thickness;                           // Node number for iris thickness
int d_PC_IRIS;									// Node number of the iris in x-direction coordinate

double Pr, Gravity;							       // Prandtl number, gravitational acceleration��dimensionless��
double PHY_ROU, PHY_MU, NIU;						 // 
double IOP, Q_In, Q_Out;				           // Intraocular pressure, outlet flow, inlet flow
double niu, chi, gravity;							// Viscosity coefficient, thermal diffusion coefficient, gravity��dimensionless��
double tau_f, Re_tau_f, tau_t, Re_tau_t;			// Relaxation time
double K_Permeability, Deta_Pressure;				// Trabecular meshwork permeability, intra- and extraocular pressure difference
double TM_Thickness;                                // Calculated trabecular mesh thickness
double U_Out_Coefficient;                           // Combined coefficients consisting of permeability, differential pressure, length of the trabecular network and dimensionless quantification of velocity
double C_AH;										// Specific heat capacity of aqueous humor 4.178E3 J/(kgK)
double Bta;                                         // Thermal expansion coefficient

double V_In, V_Out, U_In, U_Out;					// Aqueous humor flow and velocity at the outlet inlet

int *Type;											// Node type

#define  Press_Vein  1200                           // Venous blood pressure
#define  T_H  37                                    // Intraocular temperature
#define  T_L  35.3                                  // Temperature of the corneal surface
#define  Gravity_Bta    -6.5986732e-06              //Gravity*Bta  
#define  CORNEA_D 1.3221181e-7                      //Diffusion coefficient of the cornea

double   PRESSURE=1950;                             //Intraocular pressure
                           
#ifdef FORCE_STAND
   #define  U_OUT_COEF     2.5285706093779869e-08       //Combined coefficients in the standing position
#endif
#ifdef FORCE_SUPINE
  #define  U_OUT_COEF     7.0313371646543423e-08       //Combined coefficients in the spine position
#endif

int r_circle_cornea;                       //Maximum radius of corneal projection bottom circle

int up_iris_x, up_iris_y, up_iris_z;        //Coordinates of the apex of the cone on the upper surface of the iris
int dn_iris_x, dn_iris_y, dn_iris_z;        //Coordinates of the apex of the cone on the lower surface of the iris

int up_pupil_x, up_pupil_y, up_pupil_z;     //Coordinates of the centre of the circle on the upper surface of the pupil
int dn_pupil_x, dn_pupil_y, dn_pupil_z;     //Coordinates of the centre of the circle on the lower surface of the pupil
int r_circle_pupil;                         //Radius of the circle at the bottom of the pupil cylinder

int up_iris_ball_x, up_iris_ball_y, up_iris_ball_z;              
int dn_iris_ball_x, dn_iris_ball_y, dn_iris_ball_z;               
int mid_iris_ball_x, mid_iris_ball_y, mid_iris_ball_z;          
int r_iris_ball;                                                  
int r_iris_ball_x, r_iris_ball_y, r_iris_ball_z;                
int up_r_iris_ball_z, dn_r_iris_ball_z;                          
int r_iris_ball_center;                                         

int lowest_iris_ball_x, lowest_iris_ball_y, lowest_iris_ball_z;   

int lens_x, lens_y, lens_z;                                       
int d_lens_R;													 
int d_iris_lens_R;                                               
int circle_lens_x, circle_lens_y, circle_lens_z;                  
int r_circle_lens;                                              

double R_CORNEA;                                //mm  Spherical radius of the cornea
double PC_height;								//mm  Height of the posterior room
double PC_width;								//mm  Width of posterior room
double TM_HEIGHT;                               //mm  Height of the trabecular mesh
double CORNEA_thickness;                        // Thickness of the cornea
													
int center_x, center_y, center_z;
int cornea_x, cornea_y, cornea_z;				

//-------------------------------------------------------

void SetParameter();				//Initialisation parameters
void SetCornea();					//Constructing the cornea
void SetSclera();					//Constructing the sclera
void SetIris();						//Constructing the iris
void SetPupil();					//Constructing the pupil
void SetIrisBall();					//Constructing the iris bulb crown
void SetInlet();					//Constructing the posterior room inlet
void SetOutlet();					//Constructing trabecular mesh outlet
void SetLens();						//Constructing the Lens
void SetLigament();					//Constructing the lens suspensory ligament
void CheckBoundary();				//Checking the correct labelling of node types
void SetGeometry();					// Constructing the whole model
void SetOthers();

void SetParameter()
{
	R_CORNEA = 8.3;
	AC_depth = 3.0;
	IRIS_thickness = 0.4;
	CORNEA_thickness = 0.5;
	PC_height = 0.5;
	PC_width = 12.8;
	PUPIL_size = 3.0;
	D_IRIS_LENS = 0.15;
	R_LENS = 10.0;

	IRIS_ANGLE = 6.45;
	Tan_IRIS_ANGLE = tan(IRIS_ANGLE / 180 * Pi);


	TM_ANGLE = 49.0;
	Sin_TM_ANGLE = sin(TM_ANGLE / 180 * Pi);
	TM_LENGTH = 0.4;
	TM_HEIGHT = 0.345;
	d_TM = int(DetaX * TM_HEIGHT);

	d_PC_height = int(DetaX * PC_height);                      
	d_IRIS_thickness = int(DetaX * IRIS_thickness);                          
	d_PC_IRIS = int(DetaX * (PC_height + IRIS_thickness));     
}
void SetSclera()
{
	double s_h= DetaX *(PC_width/2-0.8*cos((IRIS_ANGLE + TM_ANGLE) / 180 * Pi));
	FOR_iDX_jDY
	{
		for (int k =0 ; k < DZ; k++)
		{
			double d_xx_R = Sq(double(i - cornea_x)) + Sq(double(j - cornea_y));
			int p = i*DY*DZ + j*DZ + k;
			if (d_xx_R>s_h*s_h)
			{
				if (Type[p]== CORNEA_SOLID) Type[p]= SCLERA_SOLID;
				if (Type[p]== INNER_CORNEA_BOUNDARY) Type[p]= SCLERA_SOLID;
				if (Type[p]== OUTER_CORNEA_BOUNDARY) Type[p]= OUTER_SCLERA_BOUNDARY;
				if (Type[p]== SCLERA_SOLID)
				{
					FOR_fDF
					{
						int ii = i + Ex[f], jj = j + Ey[f], kk = k + Ez[f]; 
						if (ii >= 0 && ii <= DX - 1 && jj >= 0 && jj <= DY - 1 && kk >= 0 && kk <= DZ - 1)
						{
							if (Type[ii*DY*DZ + jj*DZ + kk] == UNKNOWED)
							{
								Type[p] =OUTER_SCLERA_BOUNDARY;
							}
						}
						//if (ii < 0 || ii > DX - 1 || jj < 0 || jj > DY - 1 || kk<0 || kk> DZ - 1)
						//	Type[p] = 0; /*OUTER_SCLERA_BOUNDARY*/;
					}
				}
			}
		}
	}
	
	FOR_iDX_jDY
	{
		if (Type[i*DY*DZ + j*DZ + 0]== SCLERA_SOLID)
		{
			Type[i*DY*DZ + j*DZ + 0] =OUTER_SCLERA_BOUNDARY;
		}
	}
	
	FOR_iDX_jDY_kDZ
	{
		int p = i*DY*DZ + j*DZ + k;
		if (Type[p] == SCLERA_SOLID)
		{
			FOR_fDF
			{
				int ii = i + Ex[f], jj = j + Ey[f], kk = k + Ez[f];
				if (ii >= 0 && ii <= DX - 1 && jj >= 0 && jj <= DY - 1 && kk >= 0 && kk <= DZ - 1)
				{
					if (Type[ii*DY*DZ + jj*DZ + kk] == FLUID || Type[ii*DY*DZ + jj*DZ + kk]== CORNEA_SOLID)
					{
						Type[p] = OUTER_SCLERA_BOUNDARY;
					}
				}
			}
		}
	}
}
void SetCornea()
{
	
	center_x = DX / 2, center_y = DY / 2, center_z = 0;

	
	cornea_x = DX / 2, cornea_y = DY / 2;
	
	cornea_z = d_PC_IRIS - int(DetaX*(R_CORNEA - AC_depth));
	
	printf("centre of sphere of the cornea Z cornea_z = "); cout << cornea_z << endl;

	
	FOR_iDX_jDY_kDZ
	{
		int p = i*DY*DZ + j*DZ + k;
		Type[p] = UNKNOWED/*CORNEA_SOLID*/;
	}
	printf(" d_PC_IRIS = "); cout << d_PC_IRIS << endl;
	
	double rr1 =Sq(DetaX*(R_CORNEA + CORNEA_thickness));
	FOR_iDX_jDY
	{
		for (int k = d_PC_IRIS; k<DZ; k++)
		{
			double d_cornea_R = Sq(double(i - cornea_x)) + Sq(double(j - cornea_y)) + Sq(double(k - cornea_z));
			int p = i*DY*DZ + j*DZ + k;
			if (d_cornea_R <= rr1)
			{
				Type[p] = CORNEA_SOLID;
				FOR_fDF
				{
					INT_ii_jj_kk_IF
					{
						double d_cornea_R_m = Sq(double(ii - cornea_x)) + Sq(double(jj - cornea_y)) + Sq(double(kk - cornea_z));
						if (d_cornea_R_m > rr1)
					    //if (type[ii][jj][kk] == UNKNOWED)
						{
							Type[p]= OUTER_CORNEA_BOUNDARY;
						}
					}
				}
			}
		}
	}
	FOR_iDX_jDY
	{
		for (int k =d_PC_IRIS; k<DZ; k++)
		{
			double d_cornea_R = Sq(double(i - cornea_x)) + Sq(double(j - cornea_y)) + Sq(double(k - cornea_z));
			if (d_cornea_R <= Sq(DetaX*R_CORNEA))
			{
				int p = i*DY*DZ + j*DZ + k;
				Type[p] = FLUID;
				FOR_fDF
				{
					INT_ii_jj_kk_IF
					{
						double d_cornea_R_m = Sq(double(ii - cornea_x)) + Sq(double(jj - cornea_y)) + Sq(double(kk - cornea_z));
						if (d_cornea_R_m > Sq(DetaX*R_CORNEA))
					    //if (type[ii][jj][kk] == CORNEA_SOLID)
						{
							//type[ii][jj][kk] = INNER_CORNEA_BOUNDARY;
							Type[p] =INNER_CORNEA_BOUNDARY;
						}
					}
				}
			}
		}
	}
	
	double rr2=0;
	for (int i = 0; i<DX / 2; i++)
	{
		for (int k = DetaX * PC_height; k < d_PC_IRIS + 5; k++)
		{
			if (Type[i*DY*DZ + (DY / 2) * DZ + d_PC_IRIS] == OUTER_CORNEA_BOUNDARY)
			{
				rr2 = i;
				break;
			}
		}
	}
   rr2 = Sq(DX / 2 - rr2);
   FOR_iDX_jDY
   {
	  for (int k = 0; k <=d_PC_IRIS-1; k++)
	   {
		   double d_cornea_R = Sq(double(i - cornea_x)) + Sq(double(j - cornea_y));
		   int p = i*DY*DZ + j*DZ + k;
		   if (d_cornea_R <= rr2 && Type[p] != INNER_CORNEA_BOUNDARY)
			   Type[p] = SCLERA_SOLID;
	   }
   }
  
   FOR_iDX_jDY
   {
	   for (int k = d_PC_height; k <= d_PC_IRIS; k++)
	   {
		   double d_cornea_R = Sq(double(i - cornea_x)) + Sq(double(j - cornea_y)) + Sq(double(k - cornea_z));
		   int p = i*DY*DZ + j*DZ + k;
		   if (d_cornea_R <= Sq(DetaX*R_CORNEA) && Type[p] == SCLERA_SOLID)
		   {
			   Type[p] = IRIS_SOLID;
		   }
		} 
   }
}

void SetIris()
{
	for (int i = 0; i<DX / 2; i++)
	{
		if (Type[i*DY*DZ + (DY/2) * DZ + d_PC_IRIS] == INNER_CORNEA_BOUNDARY)
		{
			r_circle_cornea = i;
			break;
		}
	}
	printf(" r_circle_cornea = "); cout << r_circle_cornea << endl;
	r_circle_cornea = DX / 2 - r_circle_cornea;
	
	printf(" r_circle_cornea = "); cout << r_circle_cornea << endl;

	
	up_iris_x = DX / 2, up_iris_y = DY / 2;
	up_iris_z = d_PC_IRIS + r_circle_cornea*Tan_IRIS_ANGLE;
	
	printf("  up_iris_z = "); cout << up_iris_z << endl;

	FOR_iDX_jDY
	{
		for (int k = 0; k <= d_PC_IRIS; k++)
		{
			int p = i*DY*DZ + j*DZ + k;
			if ((Sq(double(i - up_iris_x)) + Sq(double(j - up_iris_y))) < Sq(double(r_circle_cornea)))
			{
				if (k < d_PC_height)
				{
					Type[p]= FLUID;
				}
				else
				{
					Type[p]= IRIS_SOLID;
				}
			}
			//else
			//{
			//	//Type[p]= CORNEA_SOLID;  //2021-12-24 del
			//	Type[p]= UNKNOWED;
			//}
		}
	}

	FOR_iDX_jDY
	{
		for (int k = d_PC_IRIS; k <= up_iris_z; k++)
		{
			int p = i*DY*DZ + j*DZ + k;
			if ((Sq(double(i - up_iris_x)) + Sq(double(j - up_iris_y))) < Sq(double(r_circle_cornea)))
			{
				double in_angle = Sq(double(k - up_iris_z)) / (Sq(double(i - up_iris_x)) + Sq(double(j - up_iris_y)));
				if (in_angle > Sq(Tan_IRIS_ANGLE))
				{
					Type[p]= IRIS_SOLID;
					FOR_fDF
					{
						INT_ii_jj_kk_IF
					{
						double out_angle = Sq(double(kk - up_iris_z)) / (Sq(double(ii - up_iris_x)) + Sq(double(jj - up_iris_y)));
					if (out_angle <= Sq(Tan_IRIS_ANGLE))
					{
						Type[p]= IRIS_BOUNDARY;
					}
					}
					}
				}
			}
		}
	}


	
	dn_iris_y = DY / 2, dn_iris_x = DX / 2;
	dn_iris_z = d_PC_height + r_circle_cornea*Tan_IRIS_ANGLE;
	
	printf("  dn_iris_z = "); cout << dn_iris_z << endl;
	FOR_iDX_jDY
	{
		for (int k = d_PC_height; k <= dn_iris_z; k++)
		{
			int p = i*DY*DZ + j*DZ + k;
			if ((Sq(j - dn_iris_y) + Sq(i - dn_iris_x)) <= Sq(r_circle_cornea))
			{
				double in_angle = Sq(double(k - dn_iris_z)) / (Sq(double(i - dn_iris_x)) + Sq(double(j - dn_iris_y)));
				if (in_angle > Sq(Tan_IRIS_ANGLE))
				{
					Type[p]= FLUID;
					FOR_fDF
					{
						INT_ii_jj_kk_IF
					{
						double out_angle = Sq(double(kk - dn_iris_z)) / (Sq(double(ii - dn_iris_x)) + Sq(double(jj - dn_iris_y)));
					if (out_angle <= Sq(Tan_IRIS_ANGLE))
					{
						Type[p]= IRIS_BOUNDARY;
					}
					}
					}
				}
			}
		}
	}

	FOR_iDX_jDY_kDZ
	{
		int p = i*DY*DZ + j*DZ + k;
		if (Type[p] == IRIS_SOLID)
		{
			FOR_fDF
			{
				INT_ii_jj_kk_IF
				{
				   int pp = ii*DY*DZ + jj*DZ + kk;
				   if (Type[pp] == FLUID)
					{
						Type[p] = IRIS_BOUNDARY;
					}
				}
			}
		}
	}

}

void SetPupil()
{
	up_pupil_y = DY / 2, up_pupil_x = DX / 2;
	
	for (int k = DZ - 1; k > d_PC_IRIS; k--)
	{
		int p = up_pupil_x*DY*DZ + up_pupil_y*DZ + k;
		if (Type[p] == IRIS_BOUNDARY)
		{
			up_pupil_z = k;
			break;
		}
	}

	dn_pupil_y = DY / 2, dn_pupil_x = DX / 2;
	
	dn_pupil_z = d_PC_height;

	printf("  up_pupil_z = "); cout << up_pupil_z << endl;
	
	printf("  dn_pupil_z = "); cout << dn_pupil_z << endl;

	r_circle_pupil = DetaX*PUPIL_size / 2;
	FOR_iDX_jDY
	{
		for (int k = dn_pupil_z; k <= up_pupil_z; k++)
		{
			if ((Sq(double(j - dn_pupil_y)) + Sq(double(i - dn_pupil_x))) <= Sq(double(r_circle_pupil)))
			{
				Type[i*DY*DZ + j*DZ + k] = FLUID;
			}
		}
	}

}

void SetIrisBall()
{
	up_iris_ball_y = DY / 2, up_iris_ball_x = DX / 2 + r_circle_pupil + 1;
	for (int k = DZ - 1; k > d_PC_IRIS; k--)
	{
		if (Type[up_iris_ball_x*DY*DZ + up_iris_ball_y*DZ + k] == IRIS_BOUNDARY)
		{
			up_iris_ball_z = k;
			break;
		}
	}

	dn_iris_ball_y = DY / 2, dn_iris_ball_x = DX / 2 + r_circle_pupil + 1;
	for (int k = 0; k<up_iris_ball_z; k++)
	{
		if (Type[dn_iris_ball_x*DY*DZ + dn_iris_ball_y*DZ + k] == IRIS_BOUNDARY)
		{
			dn_iris_ball_z = k;
			break;
		}
	}
	printf(" up_iris_ball_z = "); cout << up_iris_ball_z << endl;
	printf(" dn_iris_ball_z = "); cout << dn_iris_ball_z << endl;

	mid_iris_ball_y = DY / 2, mid_iris_ball_x = up_iris_ball_x;
	mid_iris_ball_z = (up_iris_ball_z + dn_iris_ball_z) / 2;
	
	r_iris_ball = (up_iris_ball_z - dn_iris_ball_z) / 2;
	
	r_iris_ball_y = DY / 2;
	r_iris_ball_x = mid_iris_ball_x + r_iris_ball;

	for (int k = DZ - 1; k>d_PC_IRIS; k--)
	{
		if (Type[r_iris_ball_x*DY*DZ + r_iris_ball_y*DZ + k] == IRIS_BOUNDARY)
		{
			up_r_iris_ball_z = k;
			break;
		}
	}
	for (int k = 0; k<up_r_iris_ball_z; k++)
	{
		if (Type[r_iris_ball_x*DY*DZ + r_iris_ball_y*DZ + k] == IRIS_BOUNDARY)
		{
			dn_r_iris_ball_z = k;
			break;
		}
	}

	r_iris_ball_z = (up_r_iris_ball_z + dn_r_iris_ball_z) / 2;

	r_iris_ball_center = mid_iris_ball_x + r_iris_ball;

	for (int k0 = dn_r_iris_ball_z; k0 <= up_iris_ball_z; k0++)
	{
		for (int i0 = dn_iris_ball_x; i0 <= r_iris_ball_x; i0++)
		{
			if ((Sq(double(i0 - r_iris_ball_x)) + Sq(double(k0 - r_iris_ball_z))) <= Sq(double(r_iris_ball)))
			{
				Type[i0*DY*DZ + r_iris_ball_y*DZ + k0] = IRIS_SOLID;
				for (int m0 = 0; m0<DF; m0++)
				{
					int ii0 = i0 + Ex[m0], kk0 = k0 + Ez[m0];
					if ((Sq(double(ii0 - r_iris_ball_x)) + Sq(double(kk0 - r_iris_ball_z))) > Sq(double(r_iris_ball)))
					{
						Type[ii0*DY*DZ + r_iris_ball_y*DZ + kk0] = FLUID;
				
						r_iris_ball_center = i0 - center_x;
						FOR_iDX_jDY
						{
							if ((Sq(double(j - center_y)) + Sq(double(i - center_x))) < Sq(double(r_iris_ball_center)))
							{
								Type[i*DY*DZ + j*DZ + k0] = FLUID;
								
								FOR_fDF
								{
									int ii = i + Ez[f], jj = j + Ey[f];
								if ((Sq(double(jj - center_y)) + Sq(double(ii - center_x))) >= Sq(double(r_iris_ball_center)))
								{
									Type[i*DY*DZ + j*DZ + k0] = IRIS_BOUNDARY;
								}
								}
							}
						}
					}
				}
			}
		}
	}

	
	for (int k0 = up_r_iris_ball_z; k0 <= up_iris_ball_z; k0++)
	{
		FOR_iDX_jDY
		{
			if ((Sq(double(j - center_y)) + Sq(double(i - center_x))) <= Sq(double(r_iris_ball_center)))
			{
				Type[i*DY*DZ + j*DZ + k0] = FLUID;
			}
		}
	}


	FOR_iDX_jDY_kDZ
	{
		if (Type[i*DY*DZ + j*DZ + k] == IRIS_SOLID)
		{
			FOR_fDF
			{
				INT_ii_jj_kk_IF
			{
				if (Type[ii*DY*DZ + jj*DZ + kk] == FLUID)
				{
					Type[ii*DY*DZ + jj*DZ + kk] = IRIS_BOUNDARY;
				}
			}
			}
		}
	}

}

void SetInlet()
{
	FOR_iDX_jDY
	{
		for (int k = 0; k < d_PC_height; k++)
		{
			if ((Sq(double(j - cornea_y)) + Sq(double(i - cornea_x))) < Sq(double(r_circle_cornea)))
			{
				Type[i*DY*DZ + j*DZ + k] = FLUID;
				FOR_fDF
				{
					int ii = i + Ex[f], jj = j + Ey[f], kk = k + Ez[f];
				if (kk >= 0 && kk <= d_PC_height)
				{
					if ((Sq(double(jj - cornea_y)) + Sq(double(ii - cornea_x))) >= Sq(double(r_circle_cornea)))
					{
						Type[i*DY*DZ + j*DZ + k] = PC_INLET;
					}
				}
				}
			}
		}
	}

	FOR_iDX_jDY
	{
		for (int k = 0; k <= d_PC_height; k++)
		{
			if (Type[i*DY*DZ + j*DZ + k] == FLUID)
			{
				FOR_fDF
				{
					INT_ii_jj_kk_IF
				{
					if (Type[ii*DY*DZ + jj*DZ + kk] == CORNEA_SOLID)
					{
						Type[i*DY*DZ + j*DZ + k] = PC_INLET;
					}
				}
				}
			}
		}
	}

}

void SetOutlet()
{
	FOR_iDX_jDY
	{
		for (int k = d_PC_IRIS; k <= d_PC_IRIS + d_TM; k++)
		{
			if (Type[i*DY*DZ + j*DZ + k] == INNER_CORNEA_BOUNDARY)
			{
				Type[i*DY*DZ + j*DZ + k] = TM_OUTLET;
			}
		}
	}
}

void SetLens()
{
	lowest_iris_ball_x = r_iris_ball_x;
	lowest_iris_ball_y = DY / 2;
	lowest_iris_ball_z = dn_r_iris_ball_z;
	cout << " lowest_iris_ball_z = " << lowest_iris_ball_z << endl;

	d_lens_R = DetaX * R_LENS;
	d_iris_lens_R = DetaX*(D_IRIS_LENS + R_LENS);
	lens_y = DY / 2, lens_x = DX / 2;
	for (int k = 0; k>-d_lens_R; k--)
	{
		double d = Sq(double(lowest_iris_ball_z - k)) + Sq(double(lowest_iris_ball_x - lens_x));
		if (d >= Sq(double(d_iris_lens_R)))
		{
			lens_z = k;
			break;
		}
	}
	printf("centre of sphere of the lens X lens_x : "); cout << lens_x << endl;
	printf("centre of sphere of the lens Y lens_y : "); cout << lens_y << endl;
	printf("centre of sphere of the lens Z lens_z : "); cout << lens_z << endl;

	FOR_iDX_jDY_kDZ
	{
		double d = Sq(double(j - lens_y)) + Sq(double(k - lens_z)) + Sq(double(i - lens_x));
	if (d < Sq(double(d_lens_R)))
	{
		Type[i*DY*DZ + j*DZ + k] = LENS_SOLID;
		FOR_fDF
		{
			INT_ii_jj_kk_IF
		{
			double d = Sq(double(jj - lens_y)) + Sq(double(kk - lens_z)) + Sq(double(ii - lens_x));
		if (d >= Sq(double(d_lens_R)))
		{
			Type[i*DY*DZ + j*DZ + k] = LENS_BOUNDARY;
		}
		}
		}
	}
	}

}

void SetLigament()
{
	circle_lens_z = 0;
	circle_lens_y = DY / 2, circle_lens_x = DX / 2;
	
	for (int i = circle_lens_x; i<DX - 1; i++)
	{
		if (Type[i*DY*DZ + circle_lens_y*DZ + circle_lens_z] == LENS_BOUNDARY)
		{
			r_circle_lens = i - circle_lens_x;
			break;
		}
	}

	FOR_iDX_jDY
	{
		if (((Sq(double(j - circle_lens_y)) + Sq(double(i - circle_lens_x))) <= Sq(double(r_circle_cornea)))
		&& ((Sq(double(j - circle_lens_y)) + Sq(double(i - circle_lens_x))) >= Sq(double(r_circle_lens))))
		{
			Type[i*DY*DZ + j*DZ +0] = LIGAMENT_BOUNDARY;
		}
	}

}

void CheckBoundary()
{
	FOR_iDX_jDY_kDZ
	{
		int p = i*DY*DZ + j*DZ + k;
		if (Type[p]== FLUID)
		{
			FOR_fDF
			{
				INT_ii_jj_kk_IF
				{
					if (Type[ii*DY*DZ + jj*DZ + kk] == SCLERA_SOLID) 
					{
						printf("SCLERA_SOLID boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
					if (Type[ii*DY*DZ + jj*DZ + kk] == IRIS_SOLID)
					{
						printf("IRIS_SOLID boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
					if (Type[ii*DY*DZ + jj*DZ + kk] == LENS_SOLID)
					{
						printf("LENS_SOLID boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
					if (Type[ii*DY*DZ + jj*DZ + kk] == INNER_CORNEA_BOUNDARY)
					{
						printf("INNER_CORNEA_BOUNDARY boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
					if (Type[ii*DY*DZ + jj*DZ + kk] == UNKNOWED)
					{
						printf("UNKNOWED boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
				}
			}
		}
		if (Type[p]== CORNEA_SOLID)
		{
			FOR_fDF
			{
				INT_ii_jj_kk_IF
				{
					if (Type[ii*DY*DZ + jj*DZ + kk] == UNKNOWED)
					{
						printf("CORNEA_SOLID->UNKNOWED boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
			        if(Type[ii*DY*DZ + jj*DZ + kk] == SCLERA_SOLID)
					{
						printf("CORNEA_SOLID->SCLERA_SOLID boundary error!  "); cout << i << " " << j << " " << k << endl;
					}
				}
			}
		}
		if (Type[p]== SCLERA_SOLID)
		{
			FOR_fDF
			{
				INT_ii_jj_kk_IF
			{
				if (Type[ii*DY*DZ + jj*DZ + kk] == UNKNOWED)
				{
					printf("CORNEA_SOLID->UNKNOWED boundary error!  "); cout << i << " " << j << " " << k << endl;
				}
			}
			}
		}
	}
}
void SetOthers()
{
	FOR_iDX_jDY_kDZ
	{
		if (Type[i*DY*DZ + j*DZ + k] == INNER_CORNEA_BOUNDARY)//INNER_CORNEA_BOUNDARY�������û���ã�ֻΪ��ǰ���ҵ���
		{
			Type[i*DY*DZ + j*DZ + k] = CORNEA_SOLID;
			FOR_fDF
			{
				INT_ii_jj_kk_IF
				{
					if (Type[ii*DY*DZ + jj*DZ + kk] == SCLERA_SOLID)
					{
						Type[ii*DY*DZ + jj*DZ + kk] = OUTER_SCLERA_BOUNDARY;
					}
				}
			}
		}
	}
}

void SetGeometry()
{
	SetParameter();

	SetCornea();

	SetIris();

	SetPupil();

	SetIrisBall();

	SetInlet();

	SetOutlet();

	SetLens();

	SetLigament();

	SetSclera();

	SetOthers();

	CheckBoundary();
}

