
#pragma once 

#include "boltzmann.h"
#include <sys/time.h>
#include <omp.h>
#include <fstream>
#include <iostream>
void MallocPartSparseMemory();
void SetFolwFeild();
void ShowData(int n);
void GetStartTime();
void GetEndTime();
void FreeMemorys();


void  SemiDIR_OPT_Odd()
{
    #pragma omp parallel for  num_threads(14) //Parallel processing with OpemMP

	for (long long p = 0;p < NFluid + NCornea_Solid;p++)
	{

		double r_Dist[DF - 1];
		double s_Dist[(DT - 1)];
		int s_NeiAddr[(DF - 1)];
		double reg_T = 0, reg_P = 0;
		double reg_Ux = 0, reg_Uy = 0, reg_Uz = 0;
		double reg_Uxx = 0, reg_Uyy = 0, reg_Uzz = 0;
		long long p0, pp, pt;

		long long ppp,f;
		p0 = FIndex[p];                           
												 
		int i = p0 / DY / DZ;
		int j = (p0 / DZ) % DY;
		int k = p0 % DZ;


		if (p < NFluid) 
		{
			for (f = 1; f < DF; f++)
			{
				ppp = f * (NFluid) + p;
				r_Dist[f - 1] = F[ppp];
				reg_Ux += d_Ex[f] * r_Dist[f - 1];
				reg_Uy += d_Ey[f] * r_Dist[f - 1];
				reg_Uz += d_Ez[f] * r_Dist[f - 1];
				reg_P += r_Dist[f - 1];
			}
		}
		if (p < NFluid + NCornea_Solid) 
		{
			for (f = 1; f < DT; f++)
			{
				ppp = f * (NFluid + NCornea_Solid) + p;
				s_Dist[f - 1] = T[ppp];
				reg_T += T[ppp];
			}
		}
		
		if (p < NFluid + NCornea_Solid)
		{
			for (f = 1; f < DF; f++)
			{
				s_NeiAddr[(f - 1)] = NIndex[(i + d_Ex[f]) * DY * DZ + (j + d_Ey[f]) * DZ + k + d_Ez[f]];
			}
		}

		if (p < NFluid) 
		{
			#ifdef FORCE_STAND
						reg_Uy = reg_Uy - 0.5 * (Gravity_Bta) * (reg_T - T_L); //Guo  
			#endif
			#ifdef FORCE_SUPINE
						reg_Uz = reg_Uz - 0.5 * (Gravity_Bta) * (reg_T - T_L); //Guo  
			#endif
			reg_P = 0.5 * (reg_P - d_W[0] * 1.5 * (reg_Ux * reg_Ux + reg_Uy * reg_Uy + reg_Uz * reg_Uz));

			for (f = 1; f < DF; f++)
			{
				pp = s_NeiAddr[(f - 1)];

				#ifdef FORCE_STAND //Guo
								double Fi = -(Gravity_Bta) * (reg_T - T_L) * (1.0 - 0.5 * RE_TAU_F) * d_W[f] * (3.0 * (d_Ey[f] - reg_Uy) + 9.0 * (d_Ex[f] * reg_Ux + d_Ey[f] * reg_Uy + d_Ez[f] * reg_Uz) * d_Ey[f]);
				#endif // FORCE_STAND
				#
				#ifdef FORCE_SUPINE
								double Fi = -(Gravity_Bta) * (reg_T - T_L) * (1.0 - 0.5 * RE_TAU_F) * d_W[f] * (3.0 * (d_Ez[f] - reg_Uz) + 9.0 * (d_Ex[f] * reg_Ux + d_Ey[f] * reg_Uy + d_Ez[f] * reg_Uz) * d_Ez[f]);
				#endif // FORCE_SUPINE

				pt = NFluid + NCornea_Solid + NInlet + NOutlet;
				if (pp < NFluid + NCornea_Solid)
				{
					ppp = (long long)d_Re[f] * (NFluid) + p;
					F[ppp] = r_Dist[f - 1] - RE_TAU_F * (r_Dist[f - 1] - d_Feq(f, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi;
					if (f < DT)
					{
						ppp = (long long)d_Re[f] * (NFluid + NCornea_Solid) + p;
						T[ppp] = s_Dist[(f - 1)] - RE_TAU_T * (s_Dist[(f - 1)] - d_Teq(f, reg_T, reg_Ux, reg_Uy, reg_Uz)); 
					}
				}
				else if (pp >= NFluid + NCornea_Solid && pp < pt)
				{
					p0 = (f % 2 == 0) ? f - 1 : f + 1;
					if (pp < NFluid + NCornea_Solid + NInlet)
					{
						reg_Uxx = Ux[pp];
						reg_Uyy = Uy[pp];
						reg_Uzz = Uz[pp];
					}
					else
					{
						reg_Uxx = (U_Out_Coefficient * (reg_P * IOP_QUANTI_COF - Press_Vein)) * Ux[pp]; 
						reg_Uyy = (U_Out_Coefficient * (reg_P * IOP_QUANTI_COF - Press_Vein)) * Uy[pp];
						reg_Uzz = (U_Out_Coefficient * (reg_P * IOP_QUANTI_COF - Press_Vein)) * Uz[pp];
					}
					ppp = p0 * (NFluid) + p;
					F[ppp] = d_Feq(p0, reg_P, reg_Uxx, reg_Uyy, reg_Uzz) + (1 - RE_TAU_F) * (r_Dist[p0 - 1] - d_Feq(p0, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi;
					if (f < DT)
					{
						ppp = p0 * (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(p0, T_H, reg_Uxx, reg_Uyy, reg_Uzz) + (1 - RE_TAU_T) * (s_Dist[(p0 - 1)] - d_Teq(p0, reg_T, reg_Ux, reg_Uy, reg_Uz));
					}
				}
				else if (pp >= pt && pp < pt + NOuter_cornea_boundary + NBoundary)
				{
					ppp = (long long)d_Re[f]* (NFluid) + p;
					F[ppp] = r_Dist[f - 1] - RE_TAU_F * (r_Dist[f - 1] - d_Feq(f, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi;  
					if (f < DT)
					{
						p0 = (f % 2 == 0) ? f - 1 : f + 1;
						ppp = p0 * (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(p0, T_H, 0, 0, 0) + (1 - RE_TAU_T) * (s_Dist[(p0 - 1)] - d_Teq(p0, reg_T, reg_Ux, reg_Uy, reg_Uz));	
					}
				}
			}
		}//end fuid

		if (p >= NFluid && p < NFluid + NCornea_Solid) 
		{
			pt = NFluid + NCornea_Solid + NInlet + NOutlet;
			for (f = 1; f < DT; f++)
			{
				pp = s_NeiAddr[(f - 1)];

				if (pp < NFluid + NCornea_Solid)
				{
					ppp = (long long)d_Re[f] * (NFluid + NCornea_Solid) + p;
					T[ppp] = s_Dist[(f - 1) ] - RE_TAU_T_C * (s_Dist[(f - 1)] - reg_T / 6.0); 
				}
				if (pp >= pt && pp < pt + NOuter_cornea_boundary + NBoundary)
				{
					if (pp < pt + NOuter_cornea_boundary)
					{
						ppp = (long long)d_Re[f]* (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(d_Re[f], T_L, 0, 0, 0) + (1 - RE_TAU_T_C) * (s_Dist[(d_Re[f] - 1)] - reg_T / 6.0);
					}
					else
					{
						ppp = (long long)d_Re[f]* (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(d_Re[f], T_H, 0, 0, 0) + (1 - RE_TAU_T_C) * (s_Dist[(d_Re[f] - 1)] - reg_T / 6.0);
					}
				}
			}
		}
	}
}

void SemiDIR_OPT_Even()
{
    #pragma omp parallel for  num_threads(14) //Parallel processing with OpemMP

	for (long long p = 0;p < NFluid + NCornea_Solid;p++)
	{

		double r_Dist[DF - 1];
		double s_Dist[(DT - 1)];
		int s_NeiAddr[(DF - 1)];
		double reg_T = 0, reg_P = 0;
		double reg_Ux = 0, reg_Uy = 0, reg_Uz = 0;
		double reg_Uxx = 0, reg_Uyy = 0, reg_Uzz = 0;
		long long  p0, pp, pt;
		long long f, ppp=0;
		p0 = FIndex[p];             
									
		int i = p0 / DY / DZ;
		int j = (p0 / DZ) % DY;
		int k = p0 % DZ;

		if (p < NFluid + NCornea_Solid)
		{
			for (f = 1; f < DF; f++)
			{
				s_NeiAddr[(f - 1)] = NIndex[(i + d_Ex[f]) * DY * DZ + (j + d_Ey[f]) * DZ + k + d_Ez[f]];
			}
		}

		if (p < NFluid) 
		{
			for (f = 1; f < DF; f++)
			{
				pp = s_NeiAddr[(f - 1)];

				p0 = (f % 2 == 0) ? f - 1 : f + 1;

				if (pp < NFluid)
				{
					ppp = f * (NFluid ) + pp;
					r_Dist[p0 - 1] = F[ppp];
				}
				else
				{
					ppp = p0 * (NFluid) + p;
					r_Dist[p0 - 1] = F[ppp];
				}

				reg_Ux += d_Ex[p0] * r_Dist[p0 - 1];
				reg_Uy += d_Ey[p0] * r_Dist[p0 - 1];
				reg_Uz += d_Ez[p0] * r_Dist[p0 - 1];
				reg_P += r_Dist[p0 - 1];
			}
		}

		if (p < NFluid + NCornea_Solid)
		{
			for (f = 1; f < DT; f++)
			{
				pp = s_NeiAddr[(f - 1)];

				p0 = (f % 2 == 0) ? f - 1 : f + 1;

				pt =(p0 - 1);
				if (pp < NFluid + NCornea_Solid)
				{
					ppp = f * (NFluid + NCornea_Solid) + pp;
					s_Dist[pt] = T[ppp];
				}
				else
				{
					ppp = p0 * (NFluid + NCornea_Solid) + p;
					s_Dist[pt] = T[ppp];
				}

				reg_T += s_Dist[pt];
			}
		}

		if (p < NFluid)
		{
			#ifdef FORCE_STAND
				reg_Uy = reg_Uy - 0.5 * (Gravity_Bta) * (reg_T - T_L); //Guo  
			#endif
			#ifdef FORCE_SUPINE
				reg_Uz = reg_Uz - 0.5 * (Gravity_Bta) * (reg_T - T_L); //Guo  
			#endif
			reg_P = 0.5 * (reg_P - d_W[0] * 1.5 * (reg_Ux * reg_Ux + reg_Uy * reg_Uy + reg_Uz * reg_Uz));

			for (f = 1; f < DF; f++)
			{
				pp = s_NeiAddr[(f - 1)];

				p0 = (f % 2 == 0) ? f - 1 : f + 1;

				#ifdef FORCE_STAND //Guo
					double Fi = -(Gravity_Bta) * (reg_T - T_L) * (1.0 - 0.5 * RE_TAU_F) * d_W[f] * (3.0 * (d_Ey[f] - reg_Uy) + 9.0 * (d_Ex[f] * reg_Ux + d_Ey[f] * reg_Uy + d_Ez[f] * reg_Uz) * d_Ey[f]);
				#endif // FORCE_STAND

				#ifdef FORCE_SUPINE
				   double Fi = -(Gravity_Bta) * (reg_T - T_L) * (1.0 - 0.5 * RE_TAU_F) * d_W[f] * (3.0 * (d_Ez[f] - reg_Uz) + 9.0 * (d_Ex[f] * reg_Ux + d_Ey[f] * reg_Uy + d_Ez[f] * reg_Uz) * d_Ez[f]);
				#endif // FORCE_SUPINE
				pt = NFluid + NCornea_Solid + NInlet + NOutlet;
				if (pp < NFluid + NCornea_Solid)
				{
					if (pp < NFluid)
					{
						ppp = f * (NFluid) + pp;
						F[ppp] = r_Dist[f - 1] - RE_TAU_F * (r_Dist[f - 1] - d_Feq(f, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi;
					}
					else
					{
						ppp = p0 * (NFluid) + p;
						F[ppp] = r_Dist[f - 1] - RE_TAU_F * (r_Dist[f - 1] - d_Feq(f, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi;
						if (f < DT)
						{
							ppp = f * (NFluid + NCornea_Solid) + pp;
							T[ppp] = s_Dist[(f - 1)] - RE_TAU_T * (s_Dist[(f - 1)] - d_Teq(f, reg_T, reg_Ux, reg_Uy, reg_Uz));  
						}
					}
				}
				else if (pp >= NFluid + NCornea_Solid && pp < pt)
				{
					if (pp < NFluid + NCornea_Solid + NInlet)
					{
						reg_Uxx = Ux[pp];
						reg_Uyy = Uy[pp];
						reg_Uzz = Uz[pp];
					}
					else
					{
						reg_Uxx = (U_Out_Coefficient * (reg_P * IOP_QUANTI_COF - Press_Vein)) * Ux[pp]; 
						reg_Uyy = (U_Out_Coefficient * (reg_P * IOP_QUANTI_COF - Press_Vein)) * Uy[pp];
						reg_Uzz = (U_Out_Coefficient * (reg_P * IOP_QUANTI_COF - Press_Vein)) * Uz[pp];
					}
					ppp = p0 * (NFluid) + p;
					F[ppp] = d_Feq(p0, reg_P, reg_Uxx, reg_Uyy, reg_Uzz) + (1 - RE_TAU_F) * (r_Dist[p0 - 1] - d_Feq(p0, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi;
					if (f < DT)
					{
						ppp = p0 * (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(p0, T_H, reg_Uxx, reg_Uyy, reg_Uzz) + (1 - RE_TAU_T) * (s_Dist[(p0 - 1)] - d_Teq(p0, reg_T, reg_Ux, reg_Uy, reg_Uz));
					}
				}
				else if (pp >= pt && pp < pt + NOuter_cornea_boundary + NBoundary)
				{
					ppp = p0 * (NFluid) + p;
					F[ppp] = r_Dist[f - 1] - RE_TAU_F * (r_Dist[f - 1] - d_Feq(f, reg_P, reg_Ux, reg_Uy, reg_Uz)) + Fi; 
					if (f < DT)
					{
						ppp = p0 * (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(p0, T_H, 0, 0, 0) + (1 - RE_TAU_T) * (s_Dist[(p0 - 1)] - d_Teq(p0, reg_T, reg_Ux, reg_Uy, reg_Uz));
					}
				}
			}
		}//end fuid

		if (p >= NFluid && p < NFluid + NCornea_Solid)
		{
			pt = NFluid + NCornea_Solid + NInlet + NOutlet;
			for (f = 1; f < DT; f++)
			{
				pp = s_NeiAddr[(f - 1)];

				if (pp < NFluid + NCornea_Solid)
				{
					ppp = f * (NFluid + NCornea_Solid) + pp;
					T[ppp] = s_Dist[(f - 1)] - RE_TAU_T_C * (s_Dist[(f - 1)] - reg_T / 6.0); 
				}
				if (pp >= pt && pp < pt + NOuter_cornea_boundary + NBoundary)
					if (pp < pt + NOuter_cornea_boundary)
					{
						ppp = (long long)d_Re[f]* (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(d_Re[f], T_L, 0, 0, 0) + (1 - RE_TAU_T_C) * (s_Dist[(d_Re[f] - 1)] - reg_T / 6.0);
					}
					else
					{
						ppp = (long long)d_Re[f] * (NFluid + NCornea_Solid) + p;
						T[ppp] = d_Teq(d_Re[f], T_H, 0, 0, 0) + (1 - RE_TAU_T_C) * (s_Dist[(d_Re[f] - 1)] - reg_T / 6.0);
					}
			}
		}
	}
}

void FreeMemorys()
{   
	if (NIndex != NULL)
		delete NIndex;
	if (Ux != NULL)
		delete Ux;
	if (Uy != NULL)
		delete Uy;
	if (Uz != NULL)
		delete Uz;
	if (Den != NULL)
		delete Den;
	if (FIndex != NULL)
		delete FIndex;
	if (F != NULL)
		delete F;
	if (T != NULL)
		delete T;

	if (Type != NULL)
		delete Type;
	if (Tem != NULL)
		delete Tem;
}

void MallocPartSparseMemory()
{
	int n0 = 0;
	NFluid = 0; NInlet = 0; NOutlet = 0; NBoundary=0; NX = 0; NCornea_Solid = 0;
	FOR_iDX_jDY_kDZ
	{
	    int p = i*DY*DZ + j*DZ + k;
		n0++;
		if (Type[p] == FLUID)
			NFluid++;
		if (Type[p] == PC_INLET)
			NInlet++;
		if (Type[p] == TM_OUTLET)
			NOutlet++;
		if (Type[p] == CORNEA_SOLID)
			NCornea_Solid++;
		if (Type[p] == OUTER_CORNEA_BOUNDARY)
			NOuter_cornea_boundary++;
		
		if ( Type[p] == IRIS_BOUNDARY || Type[p] == LENS_BOUNDARY 
			|| Type[p] == LIGAMENT_BOUNDARY || Type[p] == OUTER_SCLERA_BOUNDARY )

			NBoundary++;

		if ( Type[p] == IRIS_BOUNDARY || Type[p] == LENS_BOUNDARY
			|| Type[p] == LIGAMENT_BOUNDARY || Type[p] == OUTER_SCLERA_BOUNDARY
			|| Type[p] == OUTER_CORNEA_BOUNDARY 
			|| Type[p] == TM_OUTLET || Type[p] == PC_INLET
			|| Type[p] == FLUID || Type[p] == CORNEA_SOLID)
			{
				NX++; 
			}
	}
	printf("   all n0 : ");	cout << n0;		
	printf("   evolution NX : ");	cout << NX << endl;
	printf("   fluid NFluid : "); cout << NFluid;	 
	printf("   inlet NInlet : ");	cout << NInlet << endl;
	printf("   outlet NOutlet : ");	cout << NOutlet;	
	printf("   cornea_solid  NCornea_Solid : ");	cout << NCornea_Solid;
	printf("   boundary NBoundary : "); cout << NBoundary << endl;
	printf("   sparse   NX = "); cout << NX << endl;
	printf("   NFluid+ NInlet+ NOutlet+ NCornea_Solid+ NBoundary: "); cout << NFluid+ NInlet+ NOutlet+ NCornea_Solid+ NBoundary << endl;

	Tem = new double[NX];
	Den = new double[NX];


	Ux = new double[NX];
	Uy = new double[NX];
	Uz = new double[NX];

	
	FIndex = new unsigned int[NFluid + NCornea_Solid];
	NIndex = new  int[DX * DY * DZ];
	

	long long xxx = NFluid * (long long)DF;
	long long xxx1 = (NFluid + NCornea_Solid) * (long long)DT;

	cout << "Memory allocation F is  ...:" << xxx << endl;
	cout << "Memory allocation T is  ...:" << xxx1 << endl;

	F = new double[xxx];
	T = new double[xxx1];

    cout << "Memory allocation F is ok ...:" << xxx<<endl;
	cout << "Memory allocation T is ok ...:" << xxx1 << endl;
	
	if (NIndex == 0 || FIndex == 0 || Ux == 0 || Uy == 0 || Uz == 0 || Den == 0 || F == 0
		|| Tem == 0 || T == 0 )
	{
		cout << "Memory allocation is error ..." << endl << flush;
		cin.get();
		exit(1);
	}
	cout << "Memory allocation finished!." << endl;
}

void SetFolwFeild()
{
	cout << "	Part_Sparse Mode	" << endl << endl;
	SetGeometryFeild();
	MallocPartSparseMemory();

	long long d_Fluid = 0, d_PC_Inlet = 0, d_TM_Outlet = 0, d_Boundary = 0,d_Cornea_Solid=0,d_Outer_cornea_boundary=0;
	long long ppp = 0;
	FOR_iDX_jDY_kDZ
	{
		long long p = i*DY*DZ + j*DZ + k;
	    NIndex[p] = -1;

	 if (Type[p] == FLUID)
	 {
		int n = d_Fluid;
		NIndex[p] = n;
		FIndex[n] = p;

		Den[n] = IOP;
		Tem[n] = 0.5*(T_H + T_L);
		Ux[n] = 0;
		Uy[n] = 0;
		Uz[n] = 0;

		//FOR_fDF
	    for (long long f = 1; f<DF; f++)
		{
			ppp = f * (NFluid) + n;
			F[ppp] = Feq(f, Den[n], Ux[n], Uy[n], Uz[n]);
			if (f < DT)
			{
				ppp = f*(NFluid + NCornea_Solid)+n;
				T[ppp] = Teq(f, Tem[n], Ux[n], Uy[n], Uz[n]);
			}
		}

		d_Fluid++;
	}
	else if (Type[p] == CORNEA_SOLID)
	{
		int n = NFluid + d_Cornea_Solid;

		NIndex[p] = n;
		FIndex[n] = p;

		Den[n] = 0;
		Tem[n] = 0.5*(T_H + T_L);

		Ux[n] = 0;
		Uy[n] = 0;
		Uz[n] = 0;

		for (long long f = 1; f<DT; f++)
		{
			ppp = f * (NFluid + NCornea_Solid) + n;
			T[ppp] = Tem[n] / 6.0;
		}
		d_Cornea_Solid++;
	}
	else if (Type[p] == PC_INLET)
	{
		int n = NFluid + NCornea_Solid + d_PC_Inlet;
		NIndex[p] = n;

		Den[n] = 0;
		Tem[n] = T_H;

		int ii = center_x - i;
		int jj = center_y - j;
		int kk = 0;
		Ux[n] = SetU(U_In, ii, jj, kk, ii);
		Uy[n] = SetU(U_In, ii, jj, kk, jj);
		Uz[n] = SetU(U_In, ii, jj, kk, kk);

		d_PC_Inlet++;
	}
	else if (Type[p] == TM_OUTLET)
	{
		int n = NFluid + NCornea_Solid + NInlet + d_TM_Outlet;
		NIndex[p] = n;

		Den[n] = 0;
		Tem[n] = T_H;

		int ii = i - cornea_x;
		int jj = j - cornea_y;
		int kk = k - cornea_z;

		double d = sqrt(double(ii*ii + jj*jj + kk*kk)); 
		Ux[n] = ii / d;
		Uy[n] = jj / d;
		Uz[n] = kk / d;

		d_TM_Outlet++;
	}
	else if (Type[p] == OUTER_CORNEA_BOUNDARY)
	{
		int n = NFluid + NCornea_Solid + NInlet + NOutlet + d_Outer_cornea_boundary;
		NIndex[p] = n;

		Den[n] = 0;

		Tem[n] = T_L;

		Ux[n] = 0;
		Uy[n] = 0;
		Uz[n] = 0;

		d_Outer_cornea_boundary++;
	}
	else if ( Type[p] == IRIS_BOUNDARY || Type[p] == LENS_BOUNDARY || Type[p] == LIGAMENT_BOUNDARY || Type[p] == OUTER_SCLERA_BOUNDARY)
	{
		int n = NFluid + NCornea_Solid + NInlet + NOutlet + NOuter_cornea_boundary +d_Boundary;
		NIndex[p] = n;

		Den[n] = 0;

		Tem[n] = T_H;

		Ux[n] = 0;
		Uy[n] = 0;
		Uz[n] = 0;

		d_Boundary++;
	}
	}

	printf("starting transform complete to part_sparse...\n");

	printf("transform finished!!!\n");
	
	ShowData(0);
}

void ShowData(int n)
{
	total_Den = total_Tem = 0;
	double t_den = 0;
	double max_u = 0;
	long long ppp = 0;
	for (int p = 0; p < NFluid; p++)
	{
		t_den += Den[p];
	  double tmp_p=0,tmp_t=0,ux=0,uy=0,uz = 0;
	  for (long long f = 1; f<DF; f++)
	  {   
		  ppp = f * (NFluid) + p;
		  double Fpf = F[ppp];
		  ux += h_Ex[f] * Fpf;
		  uy += h_Ey[f] * Fpf;
		  uz += h_Ez[f] * Fpf;
		  tmp_p += Fpf;
		  if (f < DT)
		  {
			  ppp= f * (NFluid + NCornea_Solid) + p;
			  tmp_t += T[ppp];
		  }
	  }
	  if (Type[p] == FLUID)
	  {
		#ifdef FORCE_STAND
			uy = uy - 0.5*(Gravity_Bta) * (tmp_t - T_L); //Guo  
		#endif
		#ifdef FORCE_SUPINE
		    uz = uz - 0.5*(Gravity_Bta) * (tmp_t - T_L); //Guo   
		#endif
	  }
	  tmp_p = 0.5*(tmp_p - h_W[0] * 1.5 * (ux * ux + uy * uy + uz * uz));
	  if (max_u < sqrt(ux * ux + uy * uy + uz * uz))
		  max_u = sqrt(ux * ux + uy * uy + uz * uz);
	  total_Den += tmp_p;
	  total_Tem += tmp_t;
	}
	
	cout << setw(7) << n << "      P_total" << setiosflags(ios::fixed) << setprecision(13) << total_Den*IOP_QUANTI_COF << "     T_total" << setprecision(13) << setw(20) << total_Tem << "     P_avg" << setprecision(13) << setw(10) << total_Den*IOP_QUANTI_COF/ NFluid <<"  Max_U  "<< max_u*DimLen/ DimTime<<"  NFluid:" << NFluid << endl;
	if (n == 0)
		avg_p0 = total_Den/ NFluid;
}

int main()
{
	
	SetFolwFeild();
	
	struct timeval start1;
	struct timeval end1;
	//Evo_Start---------------------------------------
	gettimeofday(&start1, NULL);
	FOR_nALLSTEP
	{
		if (n % 2 != 0)
		{
			SemiDIR_OPT_Odd();
		}
		else
		   SemiDIR_OPT_Even();

		if (n % SHOWSTEP == 0)
		{
			ShowData(n);
			printf("timesteps=:%d\n", n);
		}
	}

	//Evo_end----------------------------------------
	gettimeofday(&end1, NULL);
    #define MSECOND 1000000
	float timeuse = MSECOND * (end1.tv_sec - start1.tv_sec) + end1.tv_usec - start1.tv_usec;
	timeuse /= MSECOND;

	double MFLUPS = (double(ALLSTEP) / 1e6) * ((NFluid + NInlet + NOutlet) / (timeuse));
	printf("MFUPS=%.2f%      16.2f\n", MFLUPS, timeuse);

	FreeMemorys();
	system("pause");
    return 0;
}

